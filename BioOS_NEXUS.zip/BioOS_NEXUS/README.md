# BioOS NEXUS — Multi-page Interactive Simulation Studio

A premium, dark-themed multi-page frontend for the existing BioOS C++ simulator. This is a **user-space educational simulation**, not a kernel or machine-learning model.

## Run on Ubuntu WSL

Download `BioOS_NEXUS.zip` to `C:\Users\veer0\Downloads`, then stop the previous BioOS server (`Ctrl+C`) and paste:

```bash
cd ~
unzip -o /mnt/c/Users/veer0/Downloads/BioOS_NEXUS.zip
cd BioOS_NEXUS
chmod +x start.sh
./start.sh
```

Open **http://localhost:5000**. Keep the terminal running.

## Pages

1. **Mission Control** (`/overview`) — hero dashboard, run metrics, comparisons, shortcuts.
2. **Workload Studio** (`/workloads`) — add/edit/remove processes, sample scenarios, CPU/memory/deadline/urgency/page-reference inputs.
3. **CPU Scheduling** (`/scheduling`) — five-algorithm comparison, CPU Gantt timeline, metrics.
4. **Memory Lab** (`/memory`) — custom reference strings, frame count, relevance mapping, FIFO/LRU/GAPR, page-by-page visualizer, rolling fault-rate warning.
5. **Predictive Intelligence** (`/intelligence`) — explainable look-ahead decisions, memory-access logs, cost formula.
6. **Access Control** (`/security`) — interactive simulated RBAC checks.

Use **Run simulation** after editing. Workload and memory options persist in the browser's localStorage. CSV export is available in the top bar.

## Technical architecture

Browser (HTML/CSS/vanilla JS) → Flask API (`app.py`) → C++17 engine (`engine/bioos.cpp`) → JSON results → charts/tables.

The simulator uses synthetic bioinformatics jobs and does not include BARSA in the comparison. Predictive BioOS is compared with FCFS, SJF, Round Robin, and Priority. GAPR/FIFO/LRU memory simulations are distinct from the CPU scheduling comparison. Memory frame count and page relevance influence GAPR behavior. Thrashing is a sliding-window page-fault-rate *warning*, not real OS thrashing. Privacy control is a demonstration, not security enforcement.

## Known limitations

- No actual OS kernel scheduling or physical page replacement.
- Page-fault service time is not included in CPU time.
- Look-ahead uses a deterministic earliest-deadline continuation, not ML.
- User data persists in the current browser only, not in a database.
- External Google Fonts improve appearance when online; system fonts are used offline.
- Desktop browser UI has not been visually verified in the target WSL environment.
