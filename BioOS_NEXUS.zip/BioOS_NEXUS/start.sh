#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
command -v g++ >/dev/null || { echo 'Install compiler: sudo apt install g++'; exit 1; }
command -v python3 >/dev/null || { echo 'Install Python 3 first'; exit 1; }
echo '[BioOS] Compiling C++ simulation engine...'
g++ -std=c++17 -O2 -Wall -Wextra engine/bioos.cpp -o engine/bioos
if ! python3 -c 'import flask' 2>/dev/null; then
 echo '[BioOS] Flask missing. Installing in local virtual environment...'
 python3 -m venv .venv || { echo 'Install venv: sudo apt install python3-venv'; exit 1; }
 .venv/bin/pip install -r requirements.txt
 exec .venv/bin/python app.py
fi
python3 app.py
