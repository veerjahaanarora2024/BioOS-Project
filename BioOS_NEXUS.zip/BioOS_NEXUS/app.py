from flask import Flask, render_template, request, jsonify, send_file
from pathlib import Path
import subprocess, io, csv, json
ROOT=Path(__file__).resolve().parent
app=Flask(__name__)
app.json.sort_keys=False
DEFAULT=[
 dict(id=1,name='Variant Analysis',arrival=0,burst=6,memory=300,deadline=12,io=60,urgency=95,genome=90,pages=[1,2,1,3,1,2]),
 dict(id=2,name='Genome Alignment',arrival=1,burst=10,memory=700,deadline=30,io=70,urgency=60,genome=95,pages=[4,5,6,4,7,5,6]),
 dict(id=3,name='DNA Filtering',arrival=2,burst=4,memory=200,deadline=18,io=50,urgency=70,genome=75,pages=[1,3,1,2]),
 dict(id=4,name='Report Generation',arrival=3,burst=3,memory=100,deadline=25,io=30,urgency=40,genome=30,pages=[2,8,2]),
 dict(id=5,name='Sequence Assembly',arrival=4,burst=8,memory=600,deadline=28,io=80,urgency=80,genome=85,pages=[5,6,7,9,5,6])]
SCENARIOS={'balanced':DEFAULT,
 'deadline':[dict(j,deadline=max(j['arrival']+j['burst'],j['deadline']-7)) for j in DEFAULT],
 'memory':[dict(j,pages=(j['pages']+[9,8,7,6,5,4])) for j in DEFAULT],
 'cpu':[dict(j,burst=j['burst']*2,deadline=j['deadline']*2) for j in DEFAULT]}
def validate(raw):
 if not isinstance(raw,list) or not 1<=len(raw)<=30:raise ValueError('Provide 1–30 processes.')
 jobs=[];ids=set()
 for x in raw:
  j={}
  for k in ['id','arrival','burst','memory','deadline','io','urgency','genome']:
   j[k]=int(x[k])
  j['name']=str(x['name']).replace('"','').replace('\n',' ')[:60]
  j['pages']=[int(p) for p in x['pages']]
  if j['id'] in ids or j['id']<1:raise ValueError('Process IDs must be unique positive integers.')
  ids.add(j['id'])
  if j['arrival']<0 or j['arrival']>10000 or not 1<=j['burst']<=10000 or j['memory']<0 or j['deadline']<0:raise ValueError('Invalid arrival, burst, memory, or deadline.')
  if any(not 0<=j[k]<=100 for k in ('io','urgency','genome')):raise ValueError('Scores must be 0–100.')
  if len(j['pages'])>500 or any(p<0 or p>10000 for p in j['pages']):raise ValueError('Invalid page reference sequence.')
  jobs.append(j)
 return jobs
def options_from_request(payload):
 opt=payload.get('options',{})
 frames=int(opt.get('frames',3))
 if not 1<=frames<=20:raise ValueError('Frame count must be 1–20.')
 refs=opt.get('references',[])
 if not isinstance(refs,list) or len(refs)>2000:raise ValueError('Provide at most 2000 page references.')
 refs=[int(v) for v in refs]
 if any(v<0 or v>10000 for v in refs):raise ValueError('Page IDs must be 0–10000.')
 relevance=opt.get('relevance',{})
 if not isinstance(relevance,dict) or len(relevance)>200:raise ValueError('Invalid relevance map.')
 rel={int(k):int(v) for k,v in relevance.items()}
 if any(k<0 or k>10000 or v<0 or v>100 for k,v in rel.items()):raise ValueError('Relevance scores must be 0–100.')
 return frames,refs,rel

def execute(jobs,options=None):
 lines=[str(len(jobs))]
 for j in jobs:lines.append(' '.join(map(str,[j[k] for k in ('id','arrival','burst','memory','deadline','io','urgency','genome')]))+' '+json.dumps(j['name'])+' '+str(len(j['pages']))+' '+' '.join(map(str,j['pages'])))
 frames,refs,rel=options_from_request({'options':options or {}})
 lines.append(str(frames)+' '+str(len(rel)))
 for page,score in rel.items():lines.append(f'{page} {score}')
 lines.append(str(len(refs))+' '+ ' '.join(map(str,refs)))
 binary=ROOT/'engine'/'bioos' 
 if not binary.exists():raise RuntimeError('C++ engine not compiled. Run ./start.sh')
 run=subprocess.run([str(binary)],input='\n'.join(lines)+'\n',text=True,capture_output=True,timeout=15,cwd=ROOT)
 if run.returncode:raise RuntimeError('C++ engine failed: '+run.stderr[:400])
 data={'results':[],'decisions':[],'frames':[],'faultSeries':[],'gantt':{},'memoryResults':[],'memoryTraces':{}}
 for line in run.stdout.splitlines():
  parts=line.split('|')
  if parts[0]=='RESULT':data['results'].append(dict(algorithm=parts[1],waiting=float(parts[2]),turnaround=float(parts[3]),missed=int(parts[4]),faults=int(parts[5]),makespan=int(parts[6])))
  elif parts[0]=='DECISION':data['decisions'].append(parts[1])
  elif parts[0]=='FRAME':data['frames'].append(parts[1])
  elif parts[0]=='FAULT':data['faultSeries'].append(int(parts[1]))
  elif parts[0]=='MEMRESULT':data['memoryResults'].append(dict(algorithm=parts[1],faults=int(parts[2]),hits=int(parts[3])))
  elif parts[0]=='MEMTRACE':data['memoryTraces'].setdefault(parts[1],[]).append(dict(page=int(parts[2]),status=parts[3],frames=parts[4]))
  elif parts[0]=='GANTT':data['gantt'].setdefault(parts[1],[]).append(parts[2])
 return data
@app.get('/')
@app.get('/<page>')
def home(page='overview'):
 if page not in ('overview','workloads','scheduling','memory','intelligence','security'):
  return 'Page not found',404
 return render_template('index.html',page=page)
@app.get('/api/scenarios')
def scenarios():return jsonify(SCENARIOS)
@app.post('/api/simulate')
def simulate():
 try:
  payload=request.get_json(force=True);jobs=validate(payload['jobs'])
  return jsonify(execute(jobs,payload.get('options')))
 except (ValueError,KeyError,TypeError,RuntimeError,subprocess.TimeoutExpired) as e:return jsonify(error=str(e)),400
@app.post('/api/export')
def export():
 try:
  payload=request.get_json(force=True);jobs=validate(payload['jobs']);rows=execute(jobs,payload.get('options'))['results'];out=io.StringIO();w=csv.DictWriter(out,fieldnames=['algorithm','waiting','turnaround','missed','faults','makespan']);w.writeheader();w.writerows(rows)
  return send_file(io.BytesIO(out.getvalue().encode()),mimetype='text/csv',as_attachment=True,download_name='bioos_comparison.csv')
 except Exception as e:return jsonify(error=str(e)),400
@app.post('/api/privacy')
def privacy():
 x=request.get_json(force=True);role=str(x.get('role','')).lower();resource=str(x.get('resource','')).lower();allowed={'researcher':{'public','deidentified'},'clinician':{'public','deidentified','clinical'},'admin':{'public','deidentified','clinical','restricted'},'guest':{'public'}}
 return jsonify(granted=resource in allowed.get(role,set()),role=role,resource=resource,note='Demonstration-only role-based access check; not real data security.')
if __name__=='__main__':app.run(host='127.0.0.1',port=5000,debug=False)
